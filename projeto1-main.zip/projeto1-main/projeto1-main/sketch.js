var a = createSprite(280,390,20,200);
var b = createSprite(320,390,20,180);
var c = createSprite(20,390,20,300);
var d = createSprite(50,390,20,500);
var e = createSprite(120,390,20,220);
var f = createSprite(150,390,20,150);
var g = createSprite(80,390,20,310);
var h = createSprite(220,390,20,340);
var i = createSprite(250,390,20,310);
var j = createSprite(390,390,20,390);
var k = createSprite(185,390,20,500);
var l = createSprite(350,390,20,500);





function draw() {
  background("black");
  drawSprites();
   
}

